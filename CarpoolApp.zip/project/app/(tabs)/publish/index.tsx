import { Redirect } from 'expo-router';

export default function PublishScreen() {
  return <Redirect href="/(tabs)/publish/new" />;
}